package layer3;

public class FriendNotFoundException extends RuntimeException {
	FriendNotFoundException(String str) {
		super(str);
	}
}
