package layer3;

public class FriendAlreadyExistsException extends RuntimeException {
	FriendAlreadyExistsException(String str) {
		super(str);
	}
}
