package com.sbi.project.layer3;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.project.layer2.Applicant;

@Repository
public class ApplicantRepositoryImpl extends BaseRepositoryImpl implements ApplicantRepository {

	@Transactional
	public void createApplication(Applicant applicant) {
		super.persist(applicant);
	}

	@Transactional
	public void modifyApplication(Applicant applicant) {
		super.merge(applicant);

	}

	@Transactional
	public void removeApplication(int applicantId) {
		Applicant appObj = super.find(Applicant.class, applicantId);
		super.remove(appObj);
	}

	
	public Applicant findApplication(int applicantId) {
		
		return super.find(Applicant.class, applicantId);
	}

	public List<Applicant> findAllApplicants() {
		return super.findAll("Applicant", Applicant.class);
	}
	
	public List<Applicant> findApplicantByMobileAndBirthDate(String mobile, LocalDate date)
	{
		
		TypedQuery<Applicant> query = entityManager.createQuery("from Applicant a where a.mobileNumber=:x and a.applicantBirthdate=:y", Applicant.class);
		query.setParameter("x", mobile);
		query.setParameter("y", date);
		List<Applicant> applicantList = query.getResultList();
	
		return applicantList;
	}

}
