package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.ApplicantRepository;


@Service
public class ApplicantServiceImpl implements ApplicantService {

	@Autowired
	ApplicantRepository appRepo;
	
	@Override
	public void createApplicationService(Applicant app) {
		
		List<Address> addressList = app.getAddressList();
		for (Address address : addressList) {
			System.out.println("found the address : "+address.getAddresstype());
			address.setApplicant(app);
		}
		//app.setAddressList(addressList);
		
		appRepo.createApplication(app);
		
		System.out.println("ApplicantServiceImpl() : created the applicants data.....");

	}
	
	public List<Applicant> getAllApplicants() {
		return appRepo.findAllApplicants();
	}
	
	public void modifyApplicantService(Applicant app) {
		
		//Applicant applicant = appRepo.findApplication(app.getApplicantId());
		System.out.println("modifyApplicantService is called....");
		
		
		appRepo.modifyApplication(app);
	}

}








