package com.sbi;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ApplicantServlet
 */
@WebServlet("/applicant")
public class ApplicantServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ApplicantServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String acType = request.getParameter("app_actype");
		String acHolderName = request.getParameter("app_name");
		String acHolderFather = request.getParameter("app_fathername");
		String acHolderDob = request.getParameter("app_dob");		
		String acHolderMobile= request.getParameter("app_mobile");
		
		String acHolderMaritalStatus = request.getParameter("app_maritalstatus");
		String acHolderOccupation = request.getParameter("app_occupation");
		
		String acHolderPermArea= request.getParameter("app_perm_area");
		String acHolderPermStreet= request.getParameter("app_perm_street");
		String acHolderPermCity= request.getParameter("app_perm_city");
		String acHolderPermState= request.getParameter("app_perm_state");
		String acHolderPermCountry= request.getParameter("app_perm_country");
		String acHolderPermPin= request.getParameter("app_perm_pin");
		
		String acHolderCorrArea= request.getParameter("app_corr_area");
		String acHolderCorrStret= request.getParameter("app_corr_street");
		String acHolderCorrCity= request.getParameter("app_corr_city");
		String acHolderCorrState= request.getParameter("app_corr_state");
		String acHolderCorrCountry= request.getParameter("app_corr_country");
		String acHolderCorrPin= request.getParameter("app_corr_pin");
		
		String acHolderAdhaar= request.getParameter("app_adhaar");
		String acHolderPanCard= request.getParameter("app_pancard");
		String acHolderPhoto= request.getParameter("app_photo");
		String acHolderAnnualIncome= request.getParameter("app_annual_income");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
