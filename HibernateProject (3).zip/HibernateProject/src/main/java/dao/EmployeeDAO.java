package dao;
import java.util.Set;

import entity.Employee;

public interface EmployeeDAO
{
	void addEmployee(Employee emplyee);
	void modifyEmployee(Employee emp);
	void deleteEmployee(int empno);
	Employee findEmployee(int empno);
	Set<Employee> findAllEmployees();
}
