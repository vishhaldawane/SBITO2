import java.time.LocalDate;

public class AssociationTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//BankAccount ba = new BankAccount();
		SavingsAccount saObj1 = new SavingsAccount(      101, "Shashi Bamne", 90000.0f, LocalDate.of(2019, 1, 10), LocalDate.of(2000, 6, 10),3.5f);
		SavingsAccount saObj2 = new SavingsAccount(      102, "Mayur Wankhede", 80000.0f, LocalDate.of(2019, 1, 10), LocalDate.of(2000, 6, 10),3.5f);

		saObj1.printSavingsAccount();
		System.out.println("---");
		saObj2.printSavingsAccount();

		System.out.println("transferring....");
		//saObj1.deposit(2000);
		//saObj2.deposit(2000);
		FundTransferService.transferFunds(saObj1, saObj2, 2000);
		System.out.println("transferred....");
		
		saObj1.printSavingsAccount();
		System.out.println("---");
		saObj2.printSavingsAccount();
		
		System.out.println("---------------");
//		FixedDepositAccount fdObj = new FixedDepositAccount(101, "Shashi Bamne", 90000.0f, LocalDate.of(2019, 1, 10), LocalDate.of(2000, 6, 10),3.5f, LocalDate.of(2025, 1, 10),120000.f);
		//fdObj.printFixedDepositAccount();
		
		//Withdrawing w = saObj1;
		//w.withdraw(2000);
		
	//	Depositing d = saObj2; 
		//d.deposit(2000);
		
		
	}

}
