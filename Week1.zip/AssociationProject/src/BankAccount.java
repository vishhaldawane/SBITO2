import java.time.LocalDate;

interface Withdrawing
{
	float withdraw(float amt);
}
interface Depositing
{
	float deposit(float amt);
}

class FundTransferService
{
	public static void transferFunds(Withdrawing source, Depositing target, float amountToTransfer)
	{
		System.out.println("TRANSFER IS IN PROGRESS...");
		source.withdraw(amountToTransfer);
		target.deposit(amountToTransfer);
		System.out.println("TRANSFERRED...");
	}
}
abstract class BankAccount implements Withdrawing,Depositing
{
	//DATA-MEMBER / fields  SECTION
	private int accountNumber;
	private String accountHolderName;
	private float accountBalance;
	private LocalDate accountOpeningDate;
	private LocalDate accountHolderBirthdate;
	private int age;
	
	//MEMBER-FUNCTIONS / methods SECTION

	public BankAccount(int accountNumber, String accountHolderName, float accountBalance, LocalDate accountOpeningDate, LocalDate accountHolderBirthdate) {
		
		System.out.println("Setting the bank account details....");
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.accountBalance= accountBalance;
		this.accountOpeningDate = accountOpeningDate;
		this.accountHolderBirthdate = accountHolderBirthdate;
		
		LocalDate todaysDate = LocalDate.now();
		
		this.age = todaysDate.getYear() - accountHolderBirthdate.getYear();
	}
	
	

	@Override
	public String toString() {
		return "BankAccount [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName
				+ ", accountBalance=" + accountBalance + ", accountOpeningDate=" + accountOpeningDate
				+ ", accountHolderBirthdate=" + accountHolderBirthdate + ", age=" + age + "]";
	}

	void printBankAccount() {
		System.out.println("Bank Account Number  : "+accountNumber);
		System.out.println("Bank Holder Name     : "+accountHolderName);
		System.out.println("Bank Account Balance : Rs."+accountBalance+"/-");
		System.out.println("Account Opening Date : "+accountOpeningDate);
		System.out.println("Account Holder DOB   : "+accountHolderBirthdate);
		System.out.println("Bank Holder's Age    : "+age+" years");
		float si = calculateSimpleInterest();
		System.out.println("Bank SI              : "+si);
		
				
		System.out.println("---------------------");
	}

	public float withdraw(float amountToWithdraw) {
		System.out.println("withdrawing...."+amountToWithdraw);
		if(amountToWithdraw > accountBalance) {
			System.out.println("Insufficient funds...!!!!");
		}
		else {
			accountBalance = accountBalance - amountToWithdraw;
		}
		
		return accountBalance;
	}
	public float deposit(float amountToDeposit) {
		System.out.println("Depositing...."+amountToDeposit);
	
		if(amountToDeposit > 50000) {
			System.out.println("please specify the source of the income...");
		}
		else {
			accountBalance = accountBalance + amountToDeposit;
		}
		return accountBalance;
	}
	
	private float calculateSimpleInterest() {
		System.out.println("Calculating simple interest....");
		float si = accountBalance * 1 * 2.5f / 100;
		return si;
	}

	void changeAccountHolderName(String newName) {
		System.out.println("changing the account holder's name to "+newName);
		accountHolderName = newName;
	}
	//BankAccount() { }
}





interface Diagnosing
{
	void doDiagnose();
}
interface Surgery extends Diagnosing
{
	void doSurgery();
}
interface HeartSurgery extends Surgery
{
	void doHeartSurgery();
}

class Doctor extends Person implements Diagnosing
{
	public void doDiagnose() {
		
	}
}
class Surgeon extends Doctor implements Surgery
{
	public void doSurgery() {
		
	}
}
class HeartSurgeon extends Surgeon implements HeartSurgery
{
	public void doHeartSurgery() {
		
	}
}

interface Liquid {
	void drink();
	void pour(); 
	void refillWater(); 
}
interface Solid
{
	public void eat();
	public void chew(); 
	public void refilPlate(); 
}








class MyObject implements Liquid, Solid
{
	public void drink() {
		
	}
	public void pour() {
		
	}
	public void refillWater() {
		
	}
	
	public void eat() {
		
	}
	public void chew() {
		
	}
	public void refilPlate() {
		
	}
}
class Test
{
	
	void test() {
	//	Liquid l;
	//	Solid s;
		MyObject mo = new MyObject();
	//	l = mo;
	//	s = mo;
		
		
		Cafe.drinkOnlyLiquidItems(mo);
	}
}
class AnotherObject extends MyObject { }
class Cafe
{
	static void drinkOnlyLiquidItems(Liquid o) {
		o.refilPlate();
		o.eat();
		o.chew();

		o.refillWater();
		o.pour();
		o.drink();
	}
}
class Hotel
{
	static void eatButNotDrink(Solid o) {
		o.refilPlate();
		o.eat();
		o.chew();
	
		o.refillWater();
		o.pour();
		o.drink();
	}
}

