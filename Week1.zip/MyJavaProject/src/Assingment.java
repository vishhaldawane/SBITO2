import java.util.Iterator;

public class Assingment {
	public static void main(String[] args) {
		
		
		// 
	}

	
}

//