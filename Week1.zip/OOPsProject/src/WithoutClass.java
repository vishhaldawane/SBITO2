
public class WithoutClass {

	public static void main(String[] args) {
	
		int accountNumber1=101;
		String accountHolder1="shashi bamne";
		float accountBalance1=90000;
		int age1=23;
		
		System.out.println("account Number      : "+accountNumber1);
		System.out.println("account Holder Name : "+accountHolder1);
		System.out.println("account Balance     : "+accountBalance1);
		System.out.println("account Holder  Age : "+age1);
	
		int accountNumber2=102;
		String accountHolder2="Mayur Wankhede";
		float accountBalance2=90500;
		int age2=21;
		
		System.out.println("account Number      : "+accountNumber2);
		System.out.println("account Holder Name : "+accountHolder2);
		System.out.println("account Balance     : "+accountBalance2);
		System.out.println("account Holder  Age : "+age2);
	

	}

}
