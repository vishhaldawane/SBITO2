

  class Surgery
  {
	public static void switchOn()
	{
	   System.out.println("Switch is on");
	}
	public static void surgeryInProgress()
	{
	   System.out.println("Surgery is in progress");
	}
	public static void switchOff()
	{
	   System.out.println("Switch is off");
	}
	public static void main(String abc[])
	{
	   System.out.println("Surgery started....");
		switchOn();
		switchOff();
		switchOn();
		switchOn();
		switchOff();
		surgeryInProgress();
		surgeryInProgress();
		surgeryInProgress();
		switchOff();
		switchOff();
		switchOff();
		surgeryInProgress();
	}
  }
