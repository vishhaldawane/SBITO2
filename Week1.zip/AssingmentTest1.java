
  class AssignmentTest1

  {

	void clap()
        {
		System.
        }
	void setFontSize(int size, String fontName, String fontStyle)
        {

        }
	String changeToUpperCase(String yourname)
	{
		return yourname.toUpperCase();
	}
	int hitSixer() 
	{
		return 6;
	}
  }