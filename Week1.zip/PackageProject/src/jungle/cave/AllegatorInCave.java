package jungle.cave;
import jungle.river.Crocodile;
public class AllegatorInCave extends Crocodile {
	void eatWithPowerJaw() {
		System.out.println("Allegator is eating with power jaw...");
		Crocodile croc = null;
		croc.swim();
		System.out.println(" defaultA   "+croc.defaultA);
		System.out.println(" publicA    "+croc.publicA);
		System.out.println(" privateA   "+croc.privateA);
		System.out.println(" protectedA "+croc.protectedA);
	}
	
}

}
