package jungle.cave;

import jungle.river.A;

class Tiger {

	public Tiger() {
		System.out.println("Tiger() is constructed......");
	}
	void roar() {
		System.out.println("Tiger is roaring...");
	}
}

class B extends A{	//CHILD
	void fun() {
		System.out.println("p "+p);
		System.out.println("q "+q);
		System.out.println("r "+r);
		System.out.println("s "+s);
		A a =null;
		System.out.println("p "+a.p);
		System.out.println("q "+a.q);
		System.out.println("r "+a.r);
		System.out.println("s "+a.s);
	}
}
class C{ //NON-CHILD
	void fee() {
		A a = new A();
		System.out.println("p "+a.p);
		System.out.println("q "+a.q);
		System.out.println("r "+a.r);
		System.out.println("s "+a.s);
	}
}