package jungle.river;

public class A {
	private   int p;
	protected int q;
	public    int r;
	          int s;	
}
class B extends A{	//CHILD
	void fun() {
		System.out.println("p "+p);
		System.out.println("q "+q);
		System.out.println("r "+r);
		System.out.println("s "+s);
	}
}
class C{ //NON-CHILD- but trust due to same folder
	void fee() {
		A a = new A();
		System.out.println("p "+a.p);
		System.out.println("q "+a.q);
		System.out.println("r "+a.r);
		System.out.println("s "+a.s);
	}
}