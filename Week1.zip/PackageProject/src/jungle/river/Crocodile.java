package jungle.river;

public class Crocodile {
	 
	          int defaultA;
	public    int publicA;
	private   int privateA;
	protected int protectedA;
	
	public Crocodile() {
		System.out.println("Crocodile is created....");
	}
	public void swim() {
		System.out.println(" defaultA   "+defaultA);
		System.out.println(" publicA    "+publicA);
		System.out.println(" privateA   "+privateA);
		System.out.println(" protectedA "+protectedA);
		System.out.println("Crocodile is swimming....");
	}
}
//river





