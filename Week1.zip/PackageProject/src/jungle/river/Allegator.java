package jungle.river;

class Allegator extends Crocodile {

	Allegator() {
		System.out.println("Allegator()... constructed...");
	}
	void eatWithPowerJaw() {
		System.out.println("Allegator is eating with power jaw...");
		//Crocodile croc = new Crocodile();
		//croc.swim();
		System.out.println(" defaultA   "+defaultA);
		System.out.println(" publicA    "+publicA);
		System.out.println(" privateA   "+privateA);
		System.out.println(" protectedA "+protectedA);
	}
	
}
