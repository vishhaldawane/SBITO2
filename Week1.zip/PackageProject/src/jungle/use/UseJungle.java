package jungle.use;

import jungle.river.Crocodile;

public class UseJungle {

	public static void main(String[] args) {
	
		Crocodile croc = new Crocodile();
		croc.swim();
		System.out.println(" defaultA   "+croc.defaultA);
		System.out.println(" publicA    "+croc.publicA);
		System.out.println(" privateA   "+croc.privateA);
		System.out.println(" protectedA "+croc.protectedA);
	}

}
