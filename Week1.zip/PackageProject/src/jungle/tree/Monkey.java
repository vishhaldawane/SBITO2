package jungle.tree;

class Monkey {

	public Monkey() {
		// TODO Auto-generated constructor stub
	}
	void swinging() {
		System.out.println("Monkey is swinging.....");
	}
}
