package jungle.tree;

class Chimpanzee extends Monkey {

	Chimpanzee() {
		System.out.println("Chimpanzee() ctor...");
		
	}
	
	void gigling() {
		System.out.println("Chimpanzee is gigling...");
	}

}
