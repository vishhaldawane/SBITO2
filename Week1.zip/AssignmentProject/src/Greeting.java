import java.awt.Frame;
public class Greeting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Greeting's main  is called... ");
		Joker  jokerObj1 = new Joker();
		
		jokerObj1.juggling();
		
		Cat cat1 = new Cat();
		cat1.meow();
		cat1.meow();
		cat1.meow();
		Tiger t1 = new Tiger();
		t1.roar();
		t1.roar();
	}

}
class Tiger
{
	void roar() {
		System.out.println("tiger is roaring....");
	}
}
class Cat
{
	void meow() {
		System.out.println("meow meow....");
	}
}

class Joker
{

	int age;
	String name;
	float salary;
	int numberOfActs;
	
	void juggling() //1
	{
		System.out.println("Joker is juggling.....");
	}
	void uniCycling() //1
	{
		System.out.println("joker is uni cycling...");
	}
	String gigling() { //4
		return "hahhah hahahaaa haaaaaa he heeee heee";
	}
	
	String  juggle(int times) //3
	{
		return "joker is juggling for "+times+" times";
	}
	void makeJoke(String theJoke) { //2
		System.out.println("the joker is joking "+theJoke);
	}
}



/*

	static void clap() {
		System.out.println("clapping....");
	}
	static void setFont(int size, String fontName, String fontStyle) {
		System.out.println("setting the font size "+size);
		System.out.println("setting the font Name "+fontName);
		System.out.println("setting the font Style "+fontStyle);
		
	}
	static String convertIntoCapitalCase( String yourname) {
		return yourname.toUpperCase();
	}
	static int hitSixer() {
		return 6;
	}
	
	static int hitBoundry() {
		return 4;
	}
	
	static int howIsThat() {
		if(100>200)
			return 1;
		else
		return 0;
	}

	System.out.println("This is awesome way to develop java coding.......");
		System.out.println("what a way to make java ...");
		clap();
		setFont(10,"Comic Sans","Italics");
		String newString = convertIntoCapitalCase("sbi java is fun");
		int score = hitSixer();
		System.out.println("new string is "+newString);
		System.out.println("score is : "+score);
		
		score= score + hitSixer();
		score= score + hitSixer();
		score= score + hitSixer();
		score= score + hitSixer();
		score= score + hitSixer();

		System.out.println("new score is "+score);
		Frame f1 = new Frame();
		Frame f2 = new Frame();
		Frame f3 = new Frame();
		
		f1.setSize(100,200);
		f2.setSize(200,300);
		f3.setSize(400,500);
		
		f1.setLocation(100, 200);
		f2.setLocation(200, 300);
		f3.setLocation(400, 500);
				
		f1.setVisible(true);
		f2.setVisible(true);
		f3.setVisible(true);


*/

