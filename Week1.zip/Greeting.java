//javac Greeting.java
  class Enquiry
  {
	public static void main(String args[])
	{
		System.out.println("Welcome to the world of Java Programming!!!");
	}
  }
  class Greet
  {
	public static void main(String args[])
	{
		System.out.println("Greet from the world of Java Programming!!!");
	}
  }
  class Welcome 
  {
	public static void main(String args[])
	{
		System.out.println("You are welcome to the world of Java Programming!!!");
	}
  }
  class Vanakkam
  {
	public static void main(String args[])
	{
		System.out.println("Vanakkam to the world of Java Programming!!!");
	}
  }