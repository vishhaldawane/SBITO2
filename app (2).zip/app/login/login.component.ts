import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username!:string; //this can be a data member of a login pojo object
  password!:string;
  msg:string="";
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  authenticateUser() {
    console.log(this.username);
    console.log(this.password);
    if(this.username=='Admin' && this.password=='Admin@123')
    {
      this.msg="Welcome to Admin Page";
      sessionStorage.setItem("user",this.username);
      this.router.navigate(['/login/admin-dashboard']);
    }
    else {
      this.msg="Welcome to User Page";
      sessionStorage.setItem("user",this.username);
      this.router.navigate(['/login/dashboard']);
    }

  }
}
