export class Payee {
    payeeId:number=0;
    payeeAccountNumber : number=0;
    payeeName: string="";
    payeeIFSCCode: string="";
    payeeNickName: string="";
}