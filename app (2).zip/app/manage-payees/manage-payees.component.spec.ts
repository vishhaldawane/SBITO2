import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagePayeesComponent } from './manage-payees.component';

describe('ManagePayeesComponent', () => {
  let component: ManagePayeesComponent;
  let fixture: ComponentFixture<ManagePayeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagePayeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePayeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
