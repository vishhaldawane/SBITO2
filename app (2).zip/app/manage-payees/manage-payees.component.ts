import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-payees',
  templateUrl: './manage-payees.component.html',
  styleUrls: ['./manage-payees.component.css']
})
export class ManagePayeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
