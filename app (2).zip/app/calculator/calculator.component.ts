import { Component, OnInit } from '@angular/core';
import { CalculatorService } from '../calculator.service';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {
  a: number=0;  b: number=0;  answer: number=0;
  
  constructor(private calcServ: CalculatorService) { //DI done by angular f/w
    console.log('CalculatorComponent() constructor...setting the CalculatorService...')
  }

  addNumbers( ){    console.log('local addNumbers()');
    this.answer=this.calcServ.addTwoNumberService(this.a,this.b);
  }
  subtractNumbers( ){    console.log('local subtractNumbers()');
    this.answer=this.calcServ.subtractTwoNumberService(this.a, this.b);
  }
  multiplyNumbers( ){    console.log('local multiplyNumbers()');
    this.answer=this.calcServ.multiplyTwoNumberService(this.a, this.b);
  }
  divideNumbers( ){    console.log('local divideNumbers()');
    this.answer=this.calcServ.divideTwoNumberService(this.a, this.b);
  }

  ngOnInit(): void {
  }


}
