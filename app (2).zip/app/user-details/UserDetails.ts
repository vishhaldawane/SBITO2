import { Address } from "./Address";
import { Company } from "./Company";

export class UserDetails {
  id: number=1;
  name: string="Leanne Graham";
  username:string="Bret";
  email: string="Sincere@april.biz";

  address: Address = new Address();

  phone: string="1-770-736-8031 x56442";
  website:string="hildegard.org";

  company: Company = new Company(); 
}

