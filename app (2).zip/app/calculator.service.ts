import { ComponentFactoryResolver, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CalculatorService {
  constructor() { }
  addTwoNumberService(x : number, y: number) : number {
    console.log(' CalculatorService:addTwoNumberService()...invoked... ')
    return x+y;
  }
  subtractTwoNumberService(x : number, y: number) : number {
    console.log(' CalculatorService:subtractTwoNumberService()...invoked... ')
    return x-y;
  }
  multiplyTwoNumberService(x : number, y: number) : number {
    console.log(' CalculatorService:multiplyTwoNumberService()...invoked... ')
    return x*y;
  }
  divideTwoNumberService(x : number, y: number) : number {
    console.log(' CalculatorService:divideTwoNumberService()...invoked... ')
    return x/y;
  }
}
