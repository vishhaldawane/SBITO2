import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletePayeesComponent } from './delete-payees.component';

describe('DeletePayeesComponent', () => {
  let component: DeletePayeesComponent;
  let fixture: ComponentFixture<DeletePayeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeletePayeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletePayeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
