import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { ViewPayeeComponent } from './view-payee/view-payee.component';
import { ViewAllPayeesComponent } from './view-all-payees/view-all-payees.component';
import { DeletePayeesComponent } from './delete-payees/delete-payees.component';



@NgModule({
  declarations: [
    AddPayeeComponent,
    ViewPayeeComponent,
    ViewAllPayeesComponent,
    DeletePayeesComponent
  ],
  imports: [
    CommonModule
  ]
})
export class PayeeModule { }
