import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-balance',
  templateUrl: './view-balance.component.html',
  styleUrls: ['./view-balance.component.css']
})
export class ViewBalanceComponent implements OnInit {

  username:string="";
  data: any ;

  constructor(private router:Router) { }

  ngOnInit(): void {
   this.data = sessionStorage.getItem("user");
   this.username=JSON.stringify(this.data);
  }

}
