import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-payees',
  templateUrl: './delete-payees.component.html',
  styleUrls: ['./delete-payees.component.css']
})
export class DeletePayeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
