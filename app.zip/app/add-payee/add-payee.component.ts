import { Component, OnInit } from '@angular/core';
import { Payee } from './Payee';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {
  payeeObj: Payee = new Payee();
  tempPayeeAccountNumber: number=0;  errMsg: string="";

  payeeArray: Payee[] = [
    {
      payeeId:1,payeeAccountNumber:123123123123,payeeName:"Jack Stallman",payeeIFSCCode:"SBI00000062",payeeNickName:"Jacky"
    },
    {
      payeeId:2,payeeAccountNumber:456456456456,payeeName:"Janet Gates",payeeIFSCCode:"SBI00000020",payeeNickName:"Jannie"
    },
    {
      payeeId:3,payeeAccountNumber:783978397839,payeeName:"Julie Barboz",payeeIFSCCode:"SBI00000019",payeeNickName:"Jul"
    },
    {
      payeeId:4,payeeAccountNumber:456456123123,payeeName:"Jane Bonanza",payeeIFSCCode:"SBI00000015",payeeNickName:"Jaan"
    },
    {
      payeeId:5,payeeAccountNumber:999909999099,payeeName:"Smith Desouza",payeeIFSCCode:"SBI00000013",payeeNickName:"Smith"
    }
  ];
  
  constructor() { }  ngOnInit(): void {  }
  verifyAccountNumber() {
    if(this.payeeObj.payeeAccountNumber != this.tempPayeeAccountNumber) {
      this.errMsg="payee account number doesnot match";
    }
    else {
      this.errMsg="";
    }
  }
  addPayee() {
    this.payeeArray.push(this.payeeObj);
  }
  deletePayee(payeeToBeDeleted:Payee) {
    console.log('delete payee'+payeeToBeDeleted.payeeId);
    this.payeeArray=this.payeeArray.
    filter(
              item  => item!==payeeToBeDeleted 
      
    );
  }
  
  tempPayeeArray: Payee[] = this.payeeArray;
  tempPayeeArray2: Payee[] = this.payeeArray;
  
  reloadPayees(payeeFound: Payee) {
    this.tempPayeeArray=this.tempPayeeArray2;//load original array of the payees each time when the function is invoked...
    //console.log('reloadPayees : '+payeeFound.payeeName);
    this.tempPayeeArray=this.tempPayeeArray.filter(item=> item.payeeName.match(payeeFound.payeeName)); //find matched pattern payees
    //console.log('temp : reloadPayees : ',this.tempPayeeArray);
    //console.log('real : reloadPayees : ',this.payeeArray);
    this.payeeArray=this.tempPayeeArray;//projected array to show on the screen 
  }
}
