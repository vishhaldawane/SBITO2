
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutCompanyComponent } from './about-us/about-company/about-company.component';
import { AboutEmployeesComponent } from './about-us/about-employees/about-employees.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { AdminDashBoardComponent } from './admin-dash-board/admin-dash-board.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';

const routes: Routes = [
  {path:'',redirectTo:'/contact-us',pathMatch:'full'},
  {path:'login',component:LoginComponent},
  {path:'dashboard',component:DashBoardComponent},
  {path:'admin-dashboard',component:AdminDashBoardComponent},
  {path:'register',component:RegisterComponent},
  {
    path:'about-us',
      children: [
        {path:'',component:AboutUsComponent},
        {path:'about-emp',component:AboutEmployeesComponent},
        {path:'about-cmp',component:AboutCompanyComponent},
      ]
  },
  {path:'contact-us',component:ContactUsComponent},
  {path:'**',component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
