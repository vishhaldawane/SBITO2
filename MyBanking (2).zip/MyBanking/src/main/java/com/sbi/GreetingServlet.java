package com.sbi;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GreetingServlet
 */
@WebServlet("/greet")
public class GreetingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GreetingServlet() {
        super();
        System.out.println("GreetingServlet() constructor....");
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("init() is called....");
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("destroy() is called....");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		LocalDateTime currentDateTime = LocalDateTime.now();
		int hod= currentDateTime.getHour();
		
		String greetMsg="";
		
		if(hod >= 4 && hod <=12) {
			greetMsg="Good Morning";
		}
		else if(hod >= 12 && hod <=13) {
			greetMsg="Good Noon";
		} 
		else if(hod >= 13 && hod <=16) {
			greetMsg="Good AfterNoon";
		}
		else if(hod >= 17 && hod <=20) {
			greetMsg="Good Evening";
		}
		else if(hod >= 20 && hod <=00) {
			greetMsg="Good Night";
		}
		else if(hod >= 00 && hod <=3) {
			greetMsg="Good MidNight";
		}
		
		String yourName = request.getParameter("myname");
		PrintWriter pw = response.getWriter();
		String clientAddress = request.getRemoteAddr();
		System.out.println("doGet() is called....from : "+clientAddress+" name is "+yourName+ " "+greetMsg);
		
		pw.println("<h1> Welcome User : "+yourName+","+greetMsg+"</h1>");
		pw.println("<h2> You are from ip adderss "+clientAddress+"</h2>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("doPost() is called....");
		doGet(request, response);
	}

}
