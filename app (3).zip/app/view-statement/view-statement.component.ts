import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-statement',
  templateUrl: './view-statement.component.html',
  styleUrls: ['./view-statement.component.css']
})
export class ViewStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
