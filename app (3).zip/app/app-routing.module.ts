
import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutCompanyComponent } from './about-us/about-company/about-company.component';
import { AboutEmployeesComponent } from './about-us/about-employees/about-employees.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { AdminDashBoardComponent } from './admin-dash-board/admin-dash-board.component';
import { RegistrationManagementComponent } from './admin-dash-board/registration-management/registration-management.component';
import { ApplicantDetailsComponent } from './applicant-details/applicant-details.component';
import { ApplicantComponent } from './applicant/applicant.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { FundsTransferComponent } from './funds-transfer/funds-transfer.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ManagePayeesComponent } from './manage-payees/manage-payees.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterComponent } from './register/register.component';
import { ViewBalanceComponent } from './view-balance/view-balance.component';
import { ViewStatementComponent } from './view-statement/view-statement.component';

const routes: Routes = [
  {path:'Applicant/:id',component:ApplicantDetailsComponent},
  {path:'Applicants',component:ApplicantComponent},
  {path:'home',component:HomeComponent},
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'register',component:RegisterComponent},
  {path:'contact-us',component:ContactUsComponent},

  {
    path:'login',      children: [
      {path:'',component:LoginComponent},
      {
        path:'dashboard',
        children:[
            {path:'',component:DashBoardComponent},
            {path:'view-balance',component:ViewBalanceComponent},
            {path:'manage-payee',component:ManagePayeesComponent},
            {path:'funds-transfer',component:FundsTransferComponent},
            {path:'view-statement',component:ViewStatementComponent},
        ]
      },
      {
        path:'admin-dashboard',
        children:[
            {path:'',component:AdminDashBoardComponent},
            {path:'register-managment',component:RegistrationManagementComponent},
        ]
      }
    ]
  },
  {path:'admin-dashboard',component:AdminDashBoardComponent},
  {
    path:'about-us',
      children: [
        {path:'',component:AboutUsComponent},
        {path:'about-emp',component:AboutEmployeesComponent},
        {path:'about-cmp',component:AboutCompanyComponent},
      ]
  },
  
  {path:'**',component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
