import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simple-interest',
  templateUrl: './simple-interest.component.html',
  styleUrls: ['./simple-interest.component.css']
})
export class SimpleInterestComponent implements OnInit {
//DATA MEMBER
    principal: number=5000;    numberOfYears: number=10;   rate : number=4.6; //DATA MEMBER
    si : number=0; //DATA MEMBER
  constructor() { }
  ngOnInit(): void {  }
  calculateSimpleInterest() { //MEMBER FUNCTION
      console.log('calculateSimpleInterest() is invoked...');
      this.si = (this.principal * this.numberOfYears * this.rate)/100;
      this.principal=this.principal+10;
  }
}
