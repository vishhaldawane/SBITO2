export class UserDetails {
    username:string="";
    password:string="";
}