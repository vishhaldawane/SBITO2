import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-management',
  templateUrl: './registration-management.component.html',
  styleUrls: ['./registration-management.component.css']
})
export class RegistrationManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
