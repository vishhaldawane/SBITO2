import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetails } from '../UserDetails';

@Component({
  selector: 'app-admin-dash-board',
  templateUrl: './admin-dash-board.component.html',
  styleUrls: ['./admin-dash-board.component.css']
})
export class AdminDashBoardComponent implements OnInit {

  userDetails!: UserDetails;
  data: any ;

  constructor(private router:Router) { }

  ngOnInit(): void {
   this.data = sessionStorage.getItem("user");
   this.userDetails=JSON.parse(this.data);
  }
  makeLogout() {
    this.router.navigate(['/login']);
  }
}
