import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetails } from '../UserDetails';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css']
})
export class DashBoardComponent implements OnInit {

  userDetails!: UserDetails;
  
  constructor(private router:Router) { }
  
  data:any;

  ngOnInit(): void {
    this.data = sessionStorage.getItem("user");
    this.userDetails = JSON.parse(this.data);
    console.log('dashboard component loaded...'+this.data);
    console.log('dashboard component loaded...'+this.userDetails.username);

  }
  makeLogout() {
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }
}
