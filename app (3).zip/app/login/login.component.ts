import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetails } from '../UserDetails';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userDetails : UserDetails= new UserDetails();
  msg:string="";
  constructor(private router:Router) { }

  ngOnInit(): void {
    console.log('login component loaded...')
  }

  authenticateUser() {
    console.log(this.userDetails.username);
    console.log(this.userDetails.password);
    if(this.userDetails.username=='Admin' && this.userDetails.password=='Admin@123')
    {
      this.msg="Welcome to Admin Page";
      console.log('login page');
      console.log(this.userDetails);
      console.log('>>'+JSON.stringify(this.userDetails));
      console.log(JSON.parse(JSON.stringify(this.userDetails)));
      sessionStorage.setItem("user",JSON.stringify(this.userDetails));
      this.router.navigate(['/login/admin-dashboard']);
    }
    else {
      this.msg="Welcome to User Page";
      sessionStorage.setItem("user",JSON.stringify(this.userDetails));
      this.router.navigate(['/login/dashboard']);
    }

  }
}

