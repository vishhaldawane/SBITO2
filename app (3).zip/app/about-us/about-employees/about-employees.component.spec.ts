import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutEmployeesComponent } from './about-employees.component';

describe('AboutEmployeesComponent', () => {
  let component: AboutEmployeesComponent;
  let fixture: ComponentFixture<AboutEmployeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AboutEmployeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
