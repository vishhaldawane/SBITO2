import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-neft-transfer',
  templateUrl: './neft-transfer.component.html',
  styleUrls: ['./neft-transfer.component.css']
})
export class NeftTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
