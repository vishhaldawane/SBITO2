import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RTGSTransferComponent } from './rtgstransfer/rtgstransfer.component';
import { NeftTransferComponent } from './neft-transfer/neft-transfer.component';
import { ImpsTransferComponent } from './imps-transfer/imps-transfer.component';



@NgModule({
  declarations: [
    RTGSTransferComponent,
    NeftTransferComponent,
    ImpsTransferComponent
  ],
  imports: [
    CommonModule
  ]
})
export class TransferModule { }
