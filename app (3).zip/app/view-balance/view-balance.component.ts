import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserDetails } from '../UserDetails';

@Component({
  selector: 'app-view-balance',
  templateUrl: './view-balance.component.html',
  styleUrls: ['./view-balance.component.css']
})
export class ViewBalanceComponent implements OnInit {

  userDetails!: UserDetails;
  data: any ;

  constructor(private router:Router) { }

  ngOnInit(): void {
    console.log('view balance  component loaded...')
   this.data = sessionStorage.getItem("user");
   this.userDetails=JSON.parse(this.data);
  }

}
