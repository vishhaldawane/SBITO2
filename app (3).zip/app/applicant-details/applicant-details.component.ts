import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ApplicantService } from '../applicant.service';
import { Applicant } from '../applicant/Applicant';

@Component({
  selector: 'app-applicant-details',
  templateUrl: './applicant-details.component.html',
  styleUrls: ['./applicant-details.component.css']
})
export class ApplicantDetailsComponent implements OnInit {

  constructor(private applicantServiceObj: ApplicantService,private _activatedRoute: ActivatedRoute, private router: Router) { }

  applicant: Applicant=new Applicant();
  selectedId: any;

  anyData: any;


  ngOnInit(): void {
    
    this._activatedRoute.paramMap.subscribe(params=> {
      this.selectedId=params.get('id');
      this.applicantServiceObj.loadAllApplicantsService().subscribe(
        (data:Applicant[])=> {
          this.anyData = data.find(a=> a.applicantId==this.selectedId);
          this.applicant = this.anyData;
        }
      )
    });

  }

  onBack():void {
    this.router.navigate(['/Applicants']);
  }
}
