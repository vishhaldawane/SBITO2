import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.Car;
import com.sbi.Engine;
import com.sbi.Piston;

public class CarTest {
	
	@Test
	public void carTest() {
		
		System.out.println("Begin main");
		
		System.out.println("Trying to create spring's container....");
		ApplicationContext ctx = 
				new ClassPathXmlApplicationContext("myspring.xml"); 
		System.out.println("Spring container created....");
		
		
		Car myCar1 = (Car) ctx.getBean("a");
		System.out.println("---------------"+myCar1);
		
		Car myCar2 =  (Car)  ctx.getBean("a");
		System.out.println("---------------"+myCar2);
		
		
		Car myCar3 = (Car)  ctx.getBean("a");
		System.out.println("---------------"+myCar3);
		
		System.out.println("End main");
		
	}
}

