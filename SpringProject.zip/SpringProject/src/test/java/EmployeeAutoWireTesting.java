import org.junit.jupiter.api.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.anno.Car;

public class EmployeeAutoWireTesting {

	@Test
	public void createCar() {
		System.out.println("Trying to create spring's container....");
		ApplicationContext ctx = 
				new ClassPathXmlApplicationContext("myspring_anno.xml"); 
		System.out.println("Spring container created....");
				Car car = (Car) ctx.getBean("carObj");
		System.out.println("car "+car);
		//car.startTheCar();
		
	}
}
