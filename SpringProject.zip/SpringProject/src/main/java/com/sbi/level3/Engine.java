package com.sbi.level3;
public class Engine {
	Piston pist;
	
	/*public Engine() {
		System.out.println("Engine() 3 ctor......");
	}*/
	
	public Engine(Piston pistRef) {
		System.out.println("Engine(Piston) 3 ctor......");
		pist = pistRef;
	}
	
	public void startTheEngine() {
		pist.firePiston();
		System.out.println("Starting the engine...");
	}
	public void stopTheEngine() {
		System.out.println("Stopping the engine...");
	}
}
