package com.sbi.level3;
/*public class DieselEngine extends Engine
{
	Piston pist;
	
	
	
	public DieselEngine(Piston pistRef) {
		super(pistRef);
		System.out.println("DieselEngine(Piston) 3 ctor......");
		pist = pistRef;
		System.out.println("------------");
	}
	
	public void startTheEngine() {
		pist.firePiston();
		System.out.println("Starting the DieselEngine...");
	}
	public void stopTheEngine() {
		System.out.println("Stopping the engine...");
	}
}*/
