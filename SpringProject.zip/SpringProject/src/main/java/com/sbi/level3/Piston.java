package com.sbi.level3;
public class Piston {
	String pistonType;
	
	public Piston(String pt) {
		System.out.println("Piston(String) 3 ctor..");
		pistonType = pt;
	}
	public void firePiston() {
		System.out.println("Piston is fired...."+pistonType);
	}
}
