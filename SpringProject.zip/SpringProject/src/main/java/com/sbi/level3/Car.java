package com.sbi.level3;

import org.springframework.beans.factory.annotation.Autowired;

public class Car {

	Engine engine ; //hasA
	
	public void setEngine(Engine engObj) {
		System.out.println("setEngine(Engine) 3 construtor.....");
		this.engine= engObj;
	}
	
	public void startTheCar() {
		engine.startTheEngine();
		System.out.println("Car is started...");
	}
	
	public void stopTheCar() {
		engine.stopTheEngine();
		System.out.println("Car is stopped...");
	}
	
}
