package com.sbi.level3;
/*public class PetrolEngine extends Engine {
	Piston pist;
	
	
	
	public PetrolEngine(Piston pistRef) {
		super(pistRef);
		System.out.println("PetrolEngine(Piston) 3 ctor......");
		pist = pistRef;
		System.out.println("------------");
	}
	
	public void startTheEngine() {
		pist.firePiston();
		System.out.println("Starting the PetrolEngine...");
	}
	public void stopTheEngine() {
		System.out.println("Stopping the PetrolEngine...");
	}
}*/
