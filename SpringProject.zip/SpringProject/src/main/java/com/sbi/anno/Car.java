package com.sbi.anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("carObj")
@Scope("prototype")
public class Car {
	
	Engine e ; //hasA

	public Car(Engine ref) {
		System.out.println("Car(Engine) anno construtor.....");
		e = ref;
	}
	
	public void startTheCar() {
		e.startTheEngine();
		System.out.println("Car is started...");
	}
	
	public void stopTheCar() {
		e.stopTheEngine();
		System.out.println("Car is stopped...");
	}

}
