package com.sbi.anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("engObj")
@Scope("prototype")
public class Engine {
	Piston pist;
	
	public Engine(Piston pistRef) {
		System.out.println("Engine(Piston) anno ctor......");
		pist = pistRef;
	}
	
	public void startTheEngine() {
		pist.firePiston();
		System.out.println("Starting the engine...");
	}
	public void stopTheEngine() {
		System.out.println("Stopping the engine...");
	}
}
