package com.sbi.anno;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("pistObj")
@Scope("prototype")
public class Piston {
	String pistonType;
	
	public Piston(@Value("TwinSpark") 
	String pt) {
		System.out.println("Piston(String) anno ctor..");
		pistonType = pt;
	}
	public void firePiston() {
		System.out.println("Piston is fired...."+pistonType);
	}
}
