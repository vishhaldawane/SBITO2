package com.sbi;
public class Engine {
	Piston pist;
	
	public Engine(Piston pistRef) {
		System.out.println("Engine() ctor......");
		pist = pistRef;
	}
	
	public void startTheEngine() {
		pist.firePiston();
		System.out.println("Starting the engine...");
	}
	public void stopTheEngine() {
		System.out.println("Stopping the engine...");
	}
}
