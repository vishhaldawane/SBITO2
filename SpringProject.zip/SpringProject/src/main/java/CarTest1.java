import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sbi.Car;
import com.sbi.Engine;
import com.sbi.Piston;

public class CarTest1 {
	public static void main(String[] args) {
		
		System.out.println("Begin main");
		
		System.out.println("Trying to create spring's container....");
		ApplicationContext ctx = 
				new ClassPathXmlApplicationContext("myspring.xml"); 
		System.out.println("Spring container created....");
		
		Piston p = new Piston("hello");
		Engine e = new Engine(p);
		Car c = new Car(e);
		
		Car myCar1 = (Car) ctx.getBean("a");
		
		System.out.println("---------------");
		Car myCar2 =  (Car)  ctx.getBean("a");
		
		System.out.println("---------------");
		Car myCar3 = (Car)  ctx.getBean("a");
		
		System.out.println("End main");
		
	}
}

