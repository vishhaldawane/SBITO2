package com.sbi.layer4;

import org.springframework.stereotype.Service;

import com.sbi.layer2.Account;
import com.sbi.layer2.Applicant;

@Service
public interface AccountService {
	void openBankAccountService(int applicantId);
}
