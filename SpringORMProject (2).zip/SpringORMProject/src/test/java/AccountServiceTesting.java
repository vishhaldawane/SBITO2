import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.layer2.Account;
import com.sbi.layer2.AccountType;
import com.sbi.layer2.Address;
import com.sbi.layer2.Applicant;
import com.sbi.layer2.ApplicationStatus;
import com.sbi.layer3.AccountRepository;
import com.sbi.layer3.ApplicantRepository;
import com.sbi.layer4.AccountService;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = "classpath:myspring.xml")
public class AccountServiceTesting {

	@Autowired
	AccountService accService;
	
	@Test
	public void openBankAccountServiceTest() {
		
		accService.openBankAccountService(17);
		
		
	}
}
