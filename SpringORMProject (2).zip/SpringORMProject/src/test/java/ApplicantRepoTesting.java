import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.layer2.Account;
import com.sbi.layer2.AccountType;
import com.sbi.layer2.Address;
import com.sbi.layer2.Applicant;
import com.sbi.layer2.ApplicationStatus;
import com.sbi.layer3.AccountRepository;
import com.sbi.layer3.ApplicantRepository;


@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = "classpath:myspring.xml")
public class ApplicantRepoTesting {

	@Autowired
	ApplicantRepository appRepo;
	
	@Test
	public void createApplicantTest() {
		Applicant applicant = new Applicant();
		
		applicant.setAccountType(AccountType.SAVINGS);
		applicant.setApplicantName("Shashi Bamne");
		applicant.setApplicantFatherName("BL Bamne");
		
		applicant.setApplicantBirthdate(LocalDate.of(1993,6,10));
		
		applicant.setMobileNumber("8827400849");
		applicant.setMarried("Unmarried");
		applicant.setOccupation("Salaried");
		
		Address permanentAddr= new Address();
		permanentAddr.setAddressType("Permanent");		permanentAddr.setArea("203, Sweet Home");		permanentAddr.setStreet("North Avenue");	permanentAddr.setState("Madhya Pradesh");		permanentAddr.setCity("Bhopal");		permanentAddr.setCountry("India");		permanentAddr.setPin(123123);		permanentAddr.setApplicant(applicant);
		
		Address corrospondanceAddr= new Address();
		corrospondanceAddr.setAddressType("Corrospondance");		corrospondanceAddr.setArea("4/33, SBI, 2th Floor");		corrospondanceAddr.setStreet("South Avenue");		corrospondanceAddr.setCity("New Mumbai");		corrospondanceAddr.setState("Maharashtra");		corrospondanceAddr.setCountry("India");		corrospondanceAddr.setPin(301302);		corrospondanceAddr.setApplicant(applicant);
		
		List<Address> addrList = new ArrayList<Address>();
		addrList.add(corrospondanceAddr); //create a new row in the Address table
		addrList.add(permanentAddr);//create a new row in the Address table
		
		applicant.setAddressList(addrList);
		
		applicant.setAdhaarNumber("923449219896");
		applicant.setPanCard("ABCDE678A");
		applicant.setPhoto("shashi.jpeg");
		applicant.setAnnualIncome(2500000);
		
		applicant.setApplicationStatus(ApplicationStatus.APPLIED);
		
		appRepo.createApplication(applicant);
	}
}
