package com.sbi.project;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer3.ApplicantRepository;

@SpringBootTest
class SpringBootRestApplicationTests {

	@Autowired
	ApplicantRepository appRepo;
	
	@Test
	void addApplicantTest() {
		
		Applicant applicant = new Applicant();
		applicant.setAccountType("CURRENT");  
		applicant.setApplicantName("JOKER");
		applicant.setApplicantFatherName("JOY");
		applicant.setApplicantBirthdate(LocalDate.now());
		applicant.setMobileNumber("1231231230");
		applicant.setMarried("MARRIED"); 
		applicant.setOccupation("BUSINESS");
		applicant.setAdhaarNumber("444455556666"); 
		applicant.setPanCard("AAAAA5555A");
		applicant.setPhoto("JOKER.JPEG"); 
		applicant.setAnnualIncome(666666);
		applicant.setApplicationStatus(ApplicationStatus.IN_PROGRESS);
		
		
				Address permAddress = new Address();
					permAddress.setArea("420, Room Mahal");
					permAddress.setStreet("Awara Street");
					permAddress.setCity("Prem Nagar");
					permAddress.setState("Maharashtra");
					permAddress.setCountry("India");
					permAddress.setPin(123);
					
				Address corrAddress = new Address();
					corrAddress.setArea("640, Beauty Mahal");
					corrAddress.setStreet("Pagal Street");
					corrAddress.setCity("Gaya Nagar");
					corrAddress.setState("Gujrat");
					corrAddress.setCountry("India");
					corrAddress.setPin(456);
					
				permAddress.setApplicant(applicant);
				corrAddress.setApplicant(applicant);
				
				List<Address> addressList = new ArrayList<Address>();
				addressList.add(permAddress);//very imp to make the row for the address table
				addressList.add(corrAddress);//very imp to make the row for the address table
				
				applicant.setAddressList(addressList); //very imp to set the fk of applicant
				
				appRepo.createApplication(applicant);
		
	}
	
	@Test
	void loadAllApplicantTest() {
		
		List<Applicant> allApplicants = appRepo.findAllApplicants();
		System.out.println("all applicant size "+allApplicants.size());
		
		for (Applicant applicant : allApplicants) {
			System.out.println("Applicant Id         : "+applicant.getApplicantId());
			System.out.println("Account Type         :  "+applicant.getAccountType());
			System.out.println("Applicant Name       : "+applicant.getApplicantName());
			System.out.println("Applicant Father     : "+applicant.getApplicantFatherName());
			System.out.println("Applicant DOB        : "+applicant.getApplicantBirthdate());
			System.out.println("Applicant Married?   : "+applicant.getMarried());
			System.out.println("Applicant Mobile     : "+applicant.getMobileNumber());
			System.out.println("Applicant Occupation : "+applicant.getOccupation());
			System.out.println("Applicant Adhaar     : "+applicant.getAdhaarNumber());
			System.out.println("Applicant PAN        : "+applicant.getPanCard());
			System.out.println("Applicant Photo      : "+applicant.getPhoto());
			System.out.println("Applicant Income     : "+applicant.getAnnualIncome());
			System.out.println("Applicant Status     : "+applicant.getApplicationStatus());
			
					List<Address> addressList = applicant.getAddressList();
					System.out.println("addressList "+addressList.size());
					for(Address address : addressList) {
						System.out.println("Address Type    : "+address.getAddresstype());
						System.out.println("Address Area    : "+address.getArea());
						System.out.println("Address Street  : "+address.getStreet());
						System.out.println("Address City    : "+address.getCity());
						System.out.println("Address State   : "+address.getState());
						System.out.println("Address Country : "+address.getCountry());
						System.out.println("Address Pin     : "+address.getPin());
						System.out.println("-------------------------");
					}
					
			System.out.println("=====================================");
		}
	}
	
	@Test
	void loadApplicantByIdTest() {
		
		Applicant applicant = appRepo.findApplication(92);
		Assertions.assertTrue(applicant!=null);
		
			System.out.println("Applicant Id         : "+applicant.getApplicantId());
			System.out.println("Account Type         :  "+applicant.getAccountType());
			System.out.println("Applicant Name       : "+applicant.getApplicantName());
			System.out.println("Applicant Father     : "+applicant.getApplicantFatherName());
			System.out.println("Applicant DOB        : "+applicant.getApplicantBirthdate());
			System.out.println("Applicant Married?   : "+applicant.getMarried());
			System.out.println("Applicant Mobile     : "+applicant.getMobileNumber());
			System.out.println("Applicant Occupation : "+applicant.getOccupation());
			System.out.println("Applicant Adhaar     : "+applicant.getAdhaarNumber());
			System.out.println("Applicant PAN        : "+applicant.getPanCard());
			System.out.println("Applicant Photo      : "+applicant.getPhoto());
			System.out.println("Applicant Income     : "+applicant.getAnnualIncome());
			System.out.println("Applicant Status     : "+applicant.getApplicationStatus());
			
					List<Address> addressList = applicant.getAddressList();
				Assertions.assertTrue(addressList.size()>0);
					
					System.out.println("addressList "+addressList.size());
					for(Address address : addressList) {
						System.out.println("Address Type    : "+address.getAddresstype());
						System.out.println("Address Area    : "+address.getArea());
						System.out.println("Address Street  : "+address.getStreet());
						System.out.println("Address City    : "+address.getCity());
						System.out.println("Address State   : "+address.getState());
						System.out.println("Address Country : "+address.getCountry());
						System.out.println("Address Pin     : "+address.getPin());
						System.out.println("-------------------------");
					}
	}
	
	@Test
	void modifyApplicantTest() {
		
		Applicant applicant = appRepo.findApplication(92);
		Assertions.assertTrue(applicant!=null);
			System.out.println("--CURRENT DETAILS--");
			System.out.println("Applicant Id         : "+applicant.getApplicantId());
			System.out.println("Account Type         :  "+applicant.getAccountType());
			System.out.println("Applicant Name       : "+applicant.getApplicantName());
			System.out.println("Applicant Father     : "+applicant.getApplicantFatherName());
			System.out.println("Applicant DOB        : "+applicant.getApplicantBirthdate());
			System.out.println("Applicant Married?   : "+applicant.getMarried());
			System.out.println("Applicant Mobile     : "+applicant.getMobileNumber());
			System.out.println("Applicant Occupation : "+applicant.getOccupation());
			System.out.println("Applicant Adhaar     : "+applicant.getAdhaarNumber());
			System.out.println("Applicant PAN        : "+applicant.getPanCard());
			System.out.println("Applicant Photo      : "+applicant.getPhoto());
			System.out.println("Applicant Income     : "+applicant.getAnnualIncome());
			System.out.println("Applicant Status     : "+applicant.getApplicationStatus());
	
					System.out.println("-- CURRENT ADDRESS LIST -- ");
					List<Address> addressList = applicant.getAddressList();
				Assertions.assertTrue(addressList.size()>0);
					
					System.out.println("addressList "+addressList.size());
					for(Address address : addressList) {
						System.out.println("Address Type    : "+address.getAddresstype());
						System.out.println("Address Area    : "+address.getArea());
						System.out.println("Address Street  : "+address.getStreet());
						System.out.println("Address City    : "+address.getCity());
						System.out.println("Address State   : "+address.getState());
						System.out.println("Address Country : "+address.getCountry());
						System.out.println("Address Pin     : "+address.getPin());
						System.out.println("-------------------------");
						
						if(address.getPin()==123) {
							System.out.println("setting the address type  as permanent");
							address.setAddresstype("Permanent");
						}
						
						if(address.getPin()==456) {
							System.out.println("setting the address type  as corrospondance");
							address.setAddresstype("Corrospondance");
						}
				}
					
				applicant.setApplicationStatus(ApplicationStatus.APPROVED);
				applicant.setAnnualIncome(applicant.getAnnualIncome()+ applicant.getAnnualIncome()*0.10);
				applicant.setOccupation("Self Employed");
				
				appRepo.modifyApplication(applicant); // request for merging it back..
				
			
	}
	
	@Test
	void deleteApplicantTest() {

		appRepo.removeApplication(78);
			
	}

}
