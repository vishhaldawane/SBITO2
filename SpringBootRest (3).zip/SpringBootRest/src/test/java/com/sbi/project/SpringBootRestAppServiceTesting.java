package com.sbi.project;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Address;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.ApplicationStatus;
import com.sbi.project.layer4.ApplicantService;

@SpringBootTest
public class SpringBootRestAppServiceTesting {

	@Autowired
	ApplicantService appService;
	
	
	@Test
	void loadAllApplicantServiceTest() {
	
		List<Applicant> allApplicants = 	appService.getAllApplicants();
		System.out.println("all applicant size "+allApplicants.size());
		
		for (Applicant applicant : allApplicants) {
			/*System.out.println("Applicant Id         : "+applicant.getApplicantId());
			System.out.println("Account Type         :  "+applicant.getAccountType());
			System.out.println("Applicant Name       : "+applicant.getApplicantName());
			System.out.println("Applicant Father     : "+applicant.getApplicantFatherName());
			System.out.println("Applicant DOB        : "+applicant.getApplicantBirthdate());
			System.out.println("Applicant Married?   : "+applicant.getMarried());
			System.out.println("Applicant Mobile     : "+applicant.getMobileNumber());
			System.out.println("Applicant Occupation : "+applicant.getOccupation());
			System.out.println("Applicant Adhaar     : "+applicant.getAdhaarNumber());
			System.out.println("Applicant PAN        : "+applicant.getPanCard());
			System.out.println("Applicant Photo      : "+applicant.getPhoto());
			System.out.println("Applicant Income     : "+applicant.getAnnualIncome());*/
			System.out.println("Applicant Status     : "+applicant.getApplicationStatus());
			
					/*List<Address> addressList = applicant.getAddressList();
					System.out.println("addressList "+addressList.size());
					for(Address address : addressList) {
						System.out.println("Address Type    : "+address.getAddresstype());
						System.out.println("Address Area    : "+address.getArea());
						System.out.println("Address Street  : "+address.getStreet());
						System.out.println("Address City    : "+address.getCity());
						System.out.println("Address State   : "+address.getState());
						System.out.println("Address Country : "+address.getCountry());
						System.out.println("Address Pin     : "+address.getPin());
						System.out.println("-------------------------");
					}*/
					
			System.out.println("=====================================");
		}
		
	}
	
	@Test
	public void addApplicantServiceTest() {
		
			Applicant applicant = new Applicant();
			applicant.setAccountType("SAVINGS");  
			applicant.setApplicantName("NARENDRA");
			applicant.setApplicantFatherName("MODI");
			applicant.setApplicantBirthdate(LocalDate.now());
			applicant.setMobileNumber("1231231230");
			applicant.setMarried("UNMARRIED"); 
			applicant.setOccupation("MINISTER");
			applicant.setAdhaarNumber("444455556666"); 
			applicant.setPanCard("AAAAA5555A");
			applicant.setPhoto("assets/narendra.jpeg"); 
			applicant.setAnnualIncome(666666);
			applicant.setApplicationStatus(ApplicationStatus.IN_PROGRESS);
			
			
					Address permAddress = new Address();
						permAddress.setAddresstype("Permanent");
						permAddress.setArea("420, Room Mahal");
						permAddress.setStreet("Awara Street");
						permAddress.setCity("Prem Nagar");
						permAddress.setState("Maharashtra");
						permAddress.setCountry("India");
						permAddress.setPin(123);
						
					Address corrAddress = new Address();
						corrAddress.setAddresstype("Corrospondance");
						corrAddress.setArea("640, Beauty Mahal");
						corrAddress.setStreet("Pagal Street");
						corrAddress.setCity("Gaya Nagar");
						corrAddress.setState("Gujrat");
						corrAddress.setCountry("India");
						corrAddress.setPin(456);
						
				//	permAddress.setApplicant(applicant);
				//	corrAddress.setApplicant(applicant);
					
					List<Address> addressList = new ArrayList<Address>();
					addressList.add(permAddress);//very imp to make the row for the address table
					addressList.add(corrAddress);//very imp to make the row for the address table
					
					applicant.setAddressList(addressList); //very imp to set the fk of applicant
					
					appService.createApplicationService(applicant);			
		}
		
	@Test
	public void changeMobileNumberTest() {
		
		List<Applicant> applicant = appService.getAllApplicants();
		
		for (Applicant applicant2 : applicant) {
			if(applicant2.getApplicantId()==30) {
				applicant2.setMobileNumber("9820333399");
				appService.modifyApplicantService(applicant2);
				break;
			}
		}
	
		
	}
}
